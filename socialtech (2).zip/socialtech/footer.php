<footer class="pie">
  <div class="wrap"><p><strong>SOCIALTECH</strong><br>Instituto Nacional San Luis</p></div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
