<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="portada" id="inicio">
  <div class="wrap">
    <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/logo.png' ); ?>" alt="Logo Horas Sociales: aprender, servir, crecer">
    <div>
      <h1>SOCIALTECH</h1>
      <p class="sub">Proyecto tecnológico grupal: base de datos para las horas sociales</p>
      <dl class="ficha">
        <div><dt>Institución</dt><dd>Instituto Nacional San Luis</dd></div>
        <div><dt>Módulo</dt><dd>1.8 Proyecto Tecnológico de Desarrollo de Páginas Web</dd></div>
        <div><dt>Docente</dt><dd>Edelmira Liduvina Ponce Durán</dd></div>
        <div><dt>Fecha</dt><dd>Lunes 5 de octubre del 2026</dd></div>
      </dl>
      <a class="boton" href="<?php echo esc_url( home_url( '/#cuenta' ) ); ?>"><?php echo is_user_logged_in() ? 'Mi cuenta' : 'Registrarse o iniciar sesión'; ?></a>
      <a class="boton boton--bd" href="<?php echo esc_url( 'http://localhost:8080/phpmyadmin/index.php?route=/server/databases' ); ?>" target="_blank" rel="noopener">Crea tu tabla de registro de horas sociales aquí</a>
    </div>
  </div>
</header>

<?php
// Lema en movimiento (de derecha a izquierda, en bucle). Se repite el grupo para que el bucle no tenga saltos.
$socialtech_lemas = array(
  'Registra tus horas, certifica tu servicio y sigue tu avance en un solo lugar',
  'Aprender · Servir · Crecer',
  'Cada hora cuenta',
);
?>
<div class="lema" role="region" aria-label="Lema de SOCIALTECH">
  <div class="lema__pista">
    <?php for ( $g = 0; $g < 2; $g++ ) : ?>
      <div class="lema__grupo"<?php echo $g ? ' aria-hidden="true"' : ''; ?>>
        <?php for ( $r = 0; $r < 2; $r++ ) : foreach ( $socialtech_lemas as $frase ) : ?>
          <span class="lema__item"><?php echo esc_html( $frase ); ?></span>
        <?php endforeach; endfor; ?>
      </div>
    <?php endfor; ?>
  </div>
</div>
