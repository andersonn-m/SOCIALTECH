<?php
/**
 * Funciones del tema SOCIALTECH.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function socialtech_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'socialtech_setup' );

function socialtech_assets() {
    wp_enqueue_style(
        'socialtech-fonts',
        'https://fonts.googleapis.com/css2?family=Archivo:wght@600;800&family=Source+Serif+4:wght@400;600&display=swap',
        array(),
        null
    );
    wp_enqueue_style( 'socialtech-style', get_stylesheet_uri(), array( 'socialtech-fonts' ), wp_get_theme()->get( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'socialtech_assets' );

function socialtech_favicon() {
    if ( ! has_site_icon() ) {
        echo '<link rel="icon" href="' . esc_url( get_template_directory_uri() . '/assets/logo.png' ) . '">' . "\n";
    }
}
add_action( 'wp_head', 'socialtech_favicon' );


/**
 * Cuentas personales dentro de la página.
 * El registro respeta el ajuste de WordPress "Cualquiera puede registrarse"
 * (Ajustes > Generales) y asigna el rol por defecto configurado en ese mismo lugar.
 */
function socialtech_volver( $codigo ) {
    wp_safe_redirect( add_query_arg( 'cuenta', $codigo, home_url( '/' ) ) . '#cuenta' );
    exit;
}

function socialtech_registrar() {
    if ( is_user_logged_in() ) {
        socialtech_volver( 'ya_sesion' );
    }

    $nonce = isset( $_POST['socialtech_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['socialtech_nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'socialtech_registro' ) || ! empty( $_POST['sitio_web'] ) ) {
        socialtech_volver( 'error_seguridad' );
    }
    if ( ! get_option( 'users_can_register' ) ) {
        socialtech_volver( 'error_cerrado' );
    }

    $nombre  = isset( $_POST['nombre'] ) ? sanitize_text_field( wp_unslash( $_POST['nombre'] ) ) : '';
    $usuario = isset( $_POST['usuario'] ) ? sanitize_user( wp_unslash( $_POST['usuario'] ), true ) : '';
    $correo  = isset( $_POST['correo'] ) ? sanitize_email( wp_unslash( $_POST['correo'] ) ) : '';
    $clave   = isset( $_POST['clave'] ) ? (string) wp_unslash( $_POST['clave'] ) : '';
    $clave2  = isset( $_POST['clave2'] ) ? (string) wp_unslash( $_POST['clave2'] ) : '';

    if ( '' === $nombre || '' === $usuario || '' === $correo || '' === $clave ) {
        socialtech_volver( 'error_campos' );
    }
    if ( ! validate_username( $usuario ) ) {
        socialtech_volver( 'error_usuario' );
    }
    if ( ! is_email( $correo ) ) {
        socialtech_volver( 'error_correo' );
    }
    if ( username_exists( $usuario ) ) {
        socialtech_volver( 'error_usuario_existe' );
    }
    if ( email_exists( $correo ) ) {
        socialtech_volver( 'error_correo_existe' );
    }
    if ( strlen( $clave ) < 8 ) {
        socialtech_volver( 'error_clave_corta' );
    }
    if ( $clave !== $clave2 ) {
        socialtech_volver( 'error_claves' );
    }

    $id = wp_insert_user( array(
        'user_login'   => $usuario,
        'user_email'   => $correo,
        'user_pass'    => $clave,
        'display_name' => $nombre,
        'first_name'   => $nombre,
        'role'         => get_option( 'default_role', 'subscriber' ),
    ) );
    if ( is_wp_error( $id ) ) {
        socialtech_volver( 'error_generico' );
    }

    wp_new_user_notification( $id, null, 'admin' ); // avisa al administrador del sitio
    wp_set_current_user( $id );
    wp_set_auth_cookie( $id );
    socialtech_volver( 'registrado' );
}
add_action( 'admin_post_nopriv_socialtech_registro', 'socialtech_registrar' );
add_action( 'admin_post_socialtech_registro', 'socialtech_registrar' );

// Si el inicio de sesión falla desde nuestra página, volver a ella con un aviso (en vez de ir a wp-login.php).
function socialtech_login_fallido() {
    $ref = wp_get_referer();
    if ( $ref && false === strpos( $ref, 'wp-login.php' ) && false === strpos( $ref, 'wp-admin' ) ) {
        socialtech_volver( 'login_error' );
    }
}
add_action( 'wp_login_failed', 'socialtech_login_fallido' );
