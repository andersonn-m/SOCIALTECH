<?php get_header(); ?>

<div class="wrap cuerpo" style="grid-template-columns:1fr">
  <main>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <article <?php post_class( 'capitulo' ); ?>>
        <header><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2></header>
        <?php the_content(); ?>
      </article>
    <?php endwhile; else : ?>
      <article class="capitulo"><header><h2>No hay contenido</h2></header><p>No se encontró nada en esta página.</p></article>
    <?php endif; ?>
  </main>
</div>

<?php get_footer(); ?>
