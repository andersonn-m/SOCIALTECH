<?php get_header(); ?>

<div class="wrap cuerpo">

  <nav class="indice" aria-label="Índice del documento">
    <h2>Índice</h2>
    <ol>
      <li><a href="<?php echo esc_url( home_url( '/#problema' ) ); ?>"><b>1</b><span>Planteamiento del problema</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#objetivos' ) ); ?>"><b>2</b><span>Objetivos</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#justificacion' ) ); ?>"><b>3</b><span>Justificación</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#marco' ) ); ?>"><b>4</b><span>Marco teórico</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#requisitos' ) ); ?>"><b>5</b><span>Análisis de requisitos</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#diseno' ) ); ?>"><b>6</b><span>Diseño del sistema</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#implementacion' ) ); ?>"><b>7</b><span>Implementación y desarrollo</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#pruebas' ) ); ?>"><b>8</b><span>Pruebas</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#resultados' ) ); ?>"><b>9</b><span>Resultados</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#conclusiones' ) ); ?>"><b>10</b><span>Conclusiones</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#anexos' ) ); ?>"><b>11</b><span>Documentación y anexos</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#referencias' ) ); ?>"><b>R</b><span>Referencias</span></a></li>
      <li><a href="<?php echo esc_url( home_url( '/#cuenta' ) ); ?>"><b>@</b><span><?php echo is_user_logged_in() ? 'Mi cuenta' : 'Registrarse / Iniciar sesión'; ?></span></a></li>
    </ol>
  </nav>

  <main>

  <!-- 1 -->
  <article class="capitulo" id="problema">
    <header><span class="num" aria-hidden="true">1</span><h2>Planteamiento del problema</h2></header>
    <p>En los centros educativos de bachillerato, el servicio social estudiantil, conocido comúnmente como “horas sociales”, es un requisito necesario para que los estudiantes puedan graduarse. Cada alumno debe cumplir una cantidad fija de horas en actividades que ayuden a la comunidad. La institución debe llevar un control claro y comprobable de ese avance durante todo el ciclo de estudios.</p>
    <p>Hoy en día, muchos centros educativos llevan este registro a mano. Usan cuadernos, hojas impresas o archivos de Excel que están repartidos entre distintos docentes y oficinas. Este método trae varios problemas. La información se pierde o se daña con facilidad. Los datos pueden estar duplicados o tener errores de transcripción. Consultar cuántas horas ha sumado un estudiante toma mucho tiempo. También es difícil hacer reportes por sección, por proyecto o por año escolar. Los estudiantes tampoco tienen una forma fácil de ver su avance.</p>
    <p>La falta de un sistema centralizado también hace que cada encargado use su propio formato y criterio de registro. Esto impide unir la información. Cuando un estudiante cambia de sección, de docente asesor o de proyecto, es común que parte de su historial no se traslade bien. Además, es difícil validar las horas reportadas. Sin un respaldo claro de las fechas, las actividades realizadas y los responsables que las certifican, es complicado comprobar que el servicio se cumplió.</p>
    <p>Esta situación causa retrasos en la entrega de constancias, molestias entre alumnos y maestros, y una carga administrativa que no hace falta para quienes están a cargo del servicio social. En épocas de fin de año o de graduación, el problema empeora. Los estudiantes que tienen horas incompletas o mal registradas pueden ver afectada su titulación, y la institución debe dedicar más tiempo a revisar los expedientes uno por uno.</p>
    <p>También, la falta de datos organizados limita la toma de decisiones. Las autoridades del centro educativo no tienen información confiable sobre cuántos estudiantes han completado sus horas. Tampoco saben cuáles proyectos tienen más participación o qué instituciones colaboran de manera constante. Esto dificulta planificar y mejorar el programa de servicio social.</p>
    <div class="destacado"><small>La necesidad</small>Es necesario tener una base de datos que junte y ordene la información de las horas sociales. Así, el registro, consulta y control serán más rápidos, seguros y confiables, y se podrán hacer reportes a tiempo para estudiantes, docentes y autoridades.</div>
  </article>

  <!-- 2 -->
  <article class="capitulo" id="objetivos">
    <header><span class="num" aria-hidden="true">2</span><h2>Objetivos</h2></header>
    <h3>Objetivo general</h3>
    <div class="destacado" style="margin-top:.6rem">Diseñar e implementar una base de datos para registrar, organizar y controlar las horas sociales de los estudiantes de bachillerato. Así se podrá buscar la información más rápido y emitir reportes y constancias con mayor facilidad.</div>
    <h3>Objetivos específicos</h3>
    <ol class="lista">
      <li>Analizar el proceso actual de registro de horas sociales para identificar sus principales deficiencias y las necesidades de información de la institución.</li>
      <li>Diseñar el modelo de datos con las entidades, atributos y relaciones que representen a estudiantes, docentes asesores, proyectos, instituciones beneficiarias y horas cumplidas.</li>
      <li>Implementar la base de datos en un sistema gestor, aplicando reglas de integridad para evitar duplicados y errores de registro.</li>
    </ol>
  </article>

  <!-- 3 -->
  <article class="capitulo" id="justificacion">
    <header><span class="num" aria-hidden="true">3</span><h2>Justificación</h2></header>
    <p>El servicio social estudiantil es una parte clave en la formación completa del bachiller. Acerca al estudiante a las necesidades de su comunidad y refuerza valores como la responsabilidad, la solidaridad y el compromiso. Por eso, el registro de las horas sociales debe manejarse con el mismo cuidado que cualquier otro requisito académico. De esto depende que el estudiante pueda graduarse.</p>
    <p>Crear una base de datos para este fin tiene sentido, primero, porque ayuda a reducir errores y pérdida de información. Al poner todos los datos en un solo lugar y usar reglas que revisan cada registro, se evitan duplicados, olvidos y diferencias entre los controles de varios docentes.</p>
    <p>En segundo lugar, esto se justifica por el ahorro de tiempo y esfuerzo administrativo. Consultar el avance de un estudiante, generar una constancia o preparar un reporte por sección dejará de ser un proceso que exige revisar documentos uno por uno. Ahora, se podrá hacer la consulta en pocos segundos.</p>
    <p>También se justifica por la transparencia y confianza que da a todos los involucrados. Los estudiantes podrán saber con claridad cuántas horas han cumplido y cuántas les faltan. Los docentes y las autoridades tendrán un respaldo comprobable de las actividades realizadas, las fechas y las instituciones beneficiarias.</p>
    <p>Por último, la base de datos ayuda a mejorar la toma de decisiones. Con la información organizada, la institución podrá ver qué proyectos tienen más participación. También podrá saber qué organizaciones colaboran más seguido y qué estudiantes necesitan seguimiento. Esto permite planear y fortalecer el programa de servicio social.</p>
    <div class="destacado claro">Este proyecto ayuda de forma directa a estudiantes, docentes y autoridades del centro educativo. Además, crea las bases para llevar un servicio social más ordenado, actual y sostenible.</div>
  </article>

  <!-- 4 -->
  <article class="capitulo" id="marco">
    <header><span class="num" aria-hidden="true">4</span><h2>Marco teórico</h2></header>
    <h3>4.1 Servicio social estudiantil</h3>
    <p>El servicio social estudiantil es una actividad que ayuda a formar a los estudiantes, ya que les permite usar sus conocimientos y valores para ayudar a la comunidad. En el nivel de bachillerato, se cumple con un número fijo de horas que los alumnos realizan en proyectos o instituciones que aprueba el centro educativo. Cumplir con estas horas es necesario para obtener el título. Además de servir para formar a los estudiantes, el servicio social requiere un registro administrativo que respalde las horas, las fechas y las actividades que realiza cada alumno.</p>
    <h3>4.2 Base de datos</h3>
    <p>Una base de datos es un grupo organizado de información relacionada, guardada de forma estructurada. Esto hace más fácil consultarla, actualizarla y analizarla. A diferencia de los archivos sueltos, ayuda a centralizar los datos, reducir la repetición y mantener la coherencia de la información.</p>
    <h3>4.3 Sistema de gestión de bases de datos (SGBD)</h3>
    <p>Un sistema gestor de bases de datos es un programa que permite crear, manejar y consultar bases de datos. Entre los más usados están MySQL, PostgreSQL, SQL Server y Microsoft Access. El SGBD controla el acceso a los datos, aplica reglas de integridad y asegura la seguridad y el respaldo de la información.</p>
    <h3>4.4 Modelo entidad-relación</h3>
    <p>El modelo entidad-relación es una herramienta de diseño que muestra la información usando entidades, como estudiante, proyecto o institución, atributos como nombre, fecha o número de horas, y las relaciones entre ellas. Sirve como base para crear el diagrama que después se convierte en tablas dentro de la base de datos.</p>
    <h3>4.5 Modelo relacional y normalización</h3>
    <p>El modelo relacional organiza los datos en tablas llamadas relaciones. Cada relación se compone de filas, que representan registros, y columnas, que corresponden a los atributos de esos registros. Este modelo facilita la consulta y manipulación de datos usando el lenguaje SQL.</p>
    <p>La normalización es un proceso que busca reducir la redundancia de datos y mejorar la integridad. Consiste en aplicar una serie de reglas llamadas formas normales:</p>
    <div class="rejilla">
      <div class="tarjeta gris"><h4>Primera forma normal</h4><p>Cada columna contiene valores atómicos, es decir, indivisibles.</p></div>
      <div class="tarjeta gris"><h4>Segunda forma normal</h4><p>Todos los atributos que no son clave dependen por completo de la clave principal.</p></div>
      <div class="tarjeta gris"><h4>Tercera forma normal</h4><p>Elimina las dependencias transitivas.</p></div>
    </div>
    <p>El objetivo de la normalización es organizar los datos de manera eficiente. Así, se evita la duplicación y se facilita el mantenimiento de la base de datos. Sin embargo, un exceso de normalización puede afectar el rendimiento en consultas complejas. Por eso, a veces se busca un equilibrio entre la normalización y la eficiencia.</p>
    <h3>4.6 Integridad de los datos</h3>
    <p>La integridad de los datos significa que la información guardada es correcta y se mantiene igual con el tiempo. Se asegura con reglas como claves primarias, claves foráneas, campos obligatorios y validaciones de formato. En el caso de las horas sociales, impide que se registren horas para estudiantes que no existen o que se repitan actividades.</p>
    <h3>4.7 Lenguaje SQL</h3>
    <p>SQL (Structured Query Language) es el lenguaje estándar para definir, manejar y consultar bases de datos relacionales. Permite insertar registros, cambiar información y crear consultas y reportes, como el total de horas acumuladas por estudiante o por sección.</p>
  </article>

  <!-- 5 -->
  <article class="capitulo" id="requisitos">
    <header><span class="num" aria-hidden="true">5</span><h2>Análisis de requisitos</h2></header>
    <h3>5.1 Usuarios del sistema</h3>
    <div class="rejilla">
      <div class="tarjeta"><h4>Administrador o encargado del servicio social</h4><p>Registra estudiantes, proyectos e instituciones, valida las horas y emite reportes y constancias.</p></div>
      <div class="tarjeta"><h4>Docente asesor</h4><p>Registra y certifica las horas de los estudiantes que tiene a su cargo.</p></div>
      <div class="tarjeta"><h4>Estudiante</h4><p>Consulta su avance de horas cumplidas y pendientes.</p></div>
      <div class="tarjeta"><h4>Autoridades del centro educativo</h4><p>Consultan reportes generales sobre el cumplimiento del servicio social.</p></div>
    </div>
    <h3>5.2 Requisitos funcionales</h3>
    <ul class="lista">
      <li>Registrar los datos de los estudiantes (código, nombre, sección, año lectivo).</li>
      <li>Registrar docentes asesores y asignarlos a secciones o proyectos.</li>
      <li>Registrar instituciones beneficiarias y los proyectos que ofrecen.</li>
      <li>Asignar estudiantes a proyectos de servicio social.</li>
      <li>Registrar las horas cumplidas con fecha, actividad, institución y docente que las certifica.</li>
      <li>Calcular automáticamente el total de horas acumuladas y las horas pendientes de cada estudiante.</li>
      <li>Generar reportes por estudiante, sección, proyecto, institución y año lectivo.</li>
      <li>Identificar a los estudiantes que ya completaron el total de horas requeridas.</li>
      <li>Permitir la emisión de constancias de cumplimiento.</li>
    </ul>
    <h3>5.3 Requisitos no funcionales</h3>
    <div class="rejilla">
      <div class="tarjeta gris"><h4>Integridad</h4><p>No permitir duplicados ni horas asociadas a estudiantes o proyectos inexistentes.</p></div>
      <div class="tarjeta gris"><h4>Seguridad</h4><p>Acceso por tipo de usuario, de modo que solo personal autorizado pueda registrar o modificar horas.</p></div>
      <div class="tarjeta gris"><h4>Disponibilidad y respaldo</h4><p>Copias de seguridad periódicas para evitar la pérdida de información.</p></div>
      <div class="tarjeta gris"><h4>Rendimiento</h4><p>Responder las consultas y reportes en pocos segundos.</p></div>
      <div class="tarjeta gris"><h4>Facilidad de uso</h4><p>Estructura clara que pueda ser utilizada por personal sin conocimientos técnicos avanzados.</p></div>
    </div>
    <h3>5.4 Reglas del negocio</h3>
    <ul class="lista">
      <li>Cada estudiante debe cumplir un total mínimo de horas sociales para graduarse (por ejemplo, 300 horas, según lo que establezca la institución).</li>
      <li>Un estudiante puede participar en varios proyectos, y un proyecto puede tener varios estudiantes.</li>
      <li>Toda hora registrada debe estar respaldada por una fecha, una actividad y un responsable que la certifique.</li>
      <li>Un proyecto pertenece a una sola institución beneficiaria, pero una institución puede tener varios proyectos.</li>
      <li>Las horas registradas no pueden ser negativas ni exceder un máximo razonable por día.</li>
    </ul>
    <h3>5.5 Entidades identificadas</h3>
    <p>Con base en los requisitos anteriores, se identifican las siguientes entidades principales. Serán la base para el diseño del modelo de datos.</p>
    <ul class="chips"><li>Estudiante</li><li>Docente</li><li>Sección</li><li>Institución</li><li>Proyecto</li><li>Registro de horas</li></ul>
  </article>

  <!-- 6 -->
  <article class="capitulo" id="diseno">
    <header><span class="num" aria-hidden="true">6</span><h2>Diseño del sistema</h2></header>
    <h3>Arquitectura en tres capas</h3>
    <p>El sistema tiene tres capas que trabajan juntas. Esta separación hace más fácil mantener el sistema y permite cambiar una de las capas sin afectar las otras.</p>
    <div class="rejilla">
      <div class="tarjeta"><h4>Capa de datos</h4><p>La base de datos está en un sistema gestor como MySQL.</p></div>
      <div class="tarjeta"><h4>Capa de lógica</h4><p>Incluye las reglas de validación y los cálculos para controlar las horas cumplidas.</p></div>
      <div class="tarjeta"><h4>Capa de presentación</h4><p>Formada por los formularios y reportes que usan los distintos usuarios.</p></div>
    </div>

    <h3>Modelo entidad-relación</h3>
    <p>Parte de las entidades identificadas en el análisis: sección, docente, estudiante, institución, proyecto e inscripción. También incluye el registro de horas. Sus relaciones son:</p>
    <ul class="lista">
      <li>Una sección agrupa a muchos estudiantes. Cada estudiante pertenece a una sola sección.</li>
      <li>Un docente asesor puede tener a cargo varias secciones o proyectos.</li>
      <li>Una institución beneficiaria puede ofrecer varios proyectos, pero cada proyecto pertenece a una única institución.</li>
      <li>Entre estudiantes y proyectos hay una relación de muchos a muchos. Se resuelve con la tabla de inscripción.</li>
      <li>De las inscripciones se derivan los registros de horas, certificados siempre por un docente responsable.</li>
    </ul>

    <h3>Diseño lógico</h3>
    <p>Cada entidad se convierte en una tabla con su clave primaria y sus claves foráneas.</p>
    <div class="rejilla">
      <div class="tabla"><h4>Sección</h4><ul><li>Nombre</li><li>Grado</li><li>Año lectivo</li><li class="fk">Docente asesor</li></ul></div>
      <div class="tabla"><h4>Docente</h4><ul><li>Nombre</li><li>Apellido</li><li>Correo</li><li>Teléfono</li></ul></div>
      <div class="tabla"><h4>Estudiante</h4><ul><li>Código</li><li>Nombre</li><li>Apellido</li><li>Fecha de nacimiento</li><li>Correo</li><li class="fk">Sección</li></ul></div>
      <div class="tabla"><h4>Institución</h4><ul><li>Nombre</li><li>Dirección</li><li>Teléfono</li><li>Persona de contacto</li></ul></div>
      <div class="tabla"><h4>Proyecto</h4><ul><li>Nombre</li><li>Descripción</li><li>Horas máximas</li><li>Estado</li><li class="fk">Institución</li></ul></div>
      <div class="tabla"><h4>Inscripción</h4><ul><li>Fecha de inicio</li><li>Estado</li><li class="fk">Estudiante</li><li class="fk">Proyecto</li></ul></div>
      <div class="tabla"><h4>Registro de horas</h4><ul><li>Fecha</li><li>Actividad</li><li>Cantidad de horas</li><li class="fk">Inscripción</li><li class="fk">Docente que certifica</li></ul></div>
    </div>
    <p class="leyenda">FK indica una clave foránea. Todas las tablas tienen una clave primaria única y no nula.</p>

    <h3>Reglas de integridad</h3>
    <ul class="lista">
      <li>El código de estudiante es único en todo el sistema.</li>
      <li>El campo de horas debe ser mayor que cero y no pasar de un máximo diario, por ejemplo, ocho horas.</li>
      <li>No se pueden registrar horas sin una inscripción válida ni sin un docente que las certifique.</li>
      <li>Una misma pareja de estudiante y proyecto no puede inscribirse dos veces.</li>
    </ul>
    <p style="margin-top:1rem">Estas reglas evitan duplicados, omisiones y datos inconsistentes.</p>

    <h3>Consultas y reportes principales</h3>
    <ul class="lista">
      <li>Total de horas acumuladas y pendientes de cada estudiante.</li>
      <li>Lista de quienes ya terminaron el servicio social.</li>
      <li>Horas cumplidas por sección y por año lectivo.</li>
      <li>Participación de los estudiantes por proyecto e institución.</li>
    </ul>
    <p style="margin-top:1rem">Estas consultas se hacen con el lenguaje SQL. El sistema suma las horas registradas en cada inscripción y las agrupa según el criterio que se necesite.</p>
  </article>

  <!-- 7 -->
  <article class="capitulo" id="implementacion">
    <header><span class="num" aria-hidden="true">7</span><h2>Implementación y desarrollo</h2></header>
    <h3>Herramientas de trabajo</h3>
    <p>La implementación empieza con la elección de las herramientas. Esta elección busca que el sistema sea barato, fácil de instalar y de mantener por el personal del centro educativo.</p>
    <div class="rejilla">
      <div class="tarjeta"><h4>Capa de datos</h4><p>Se usará MySQL como sistema gestor de bases de datos.</p></div>
      <div class="tarjeta"><h4>Administración</h4><p>Una herramienta gráfica como MySQL Workbench o phpMyAdmin, para crear tablas, ejecutar consultas y revisar los datos.</p></div>
      <div class="tarjeta"><h4>Capa de presentación</h4><p>Formularios y reportes en una aplicación sencilla, web o de escritorio, según los recursos y conocimientos de la institución.</p></div>
    </div>

    <h3>Fases del desarrollo</h3>
    <ol class="fases">
      <li><h4>Crear la base de datos</h4><p>Se definen las tablas con sus tipos de datos, claves primarias, claves foráneas y restricciones de integridad, siguiendo el diseño lógico hecho antes.</p></li>
      <li><h4>Cargar los datos iniciales</h4><p>Se cargan las secciones, los docentes, las instituciones beneficiarias, los proyectos disponibles y el listado de estudiantes de cada sección. Puede hacerse con los archivos de Excel que la institución ya usa, así se reduce la digitación y se aprovecha la información que ya existe.</p></li>
      <li><h4>Consultas, validaciones y formularios</h4><p>Se crean las consultas, vistas y procedimientos que calculan las horas acumuladas y pendientes, muestran a quienes ya terminaron y resumen la participación por sección, proyecto e institución. Se agregan validaciones que no dejan registrar horas negativas, pasar el máximo diario ni poner horas en inscripciones que no existen. Después se arman los formularios y reportes para el encargado del servicio social, los docentes asesores y los estudiantes, cada uno con los permisos que le tocan según su rol.</p></li>
      <li><h4>Pruebas y respaldos</h4><p>Se ingresan datos de ejemplo para comprobar que los cálculos sean correctos, que las restricciones rechacen los datos inválidos y que los reportes muestren lo esperado. Se corrigen los errores antes de ponerlo en uso. También se configuran las copias de seguridad periódicas y se comprueba que la información pueda restaurarse en caso de falla.</p></li>
      <li><h4>Puesta en marcha</h4><p>Se capacita al personal encargado y a los docentes asesores, y se entrega un manual breve de uso. Durante las primeras semanas se brinda acompañamiento para resolver dudas y ajustar detalles. Así, la base de datos reemplaza poco a poco los registros manuales usados hasta ahora.</p></li>
    </ol>
  </article>

  <!-- 8 -->
  <article class="capitulo" id="pruebas">
    <header><span class="num" aria-hidden="true">8</span><h2>Pruebas</h2></header>
    <p>Las pruebas buscan comprobar que la base de datos cumple con los requisitos definidos en el análisis y que la información que maneja es confiable. Para esto se aplican distintos tipos de verificación.</p>
    <div class="rejilla">
      <div class="tarjeta"><h4>Estructura</h4><p>Se revisa que las tablas, campos, tipos de datos y relaciones se hayan creado como se estableció en el diseño lógico. Se confirma que las claves primarias y foráneas funcionen y que no existan tablas aisladas ni campos mal definidos.</p></div>
      <div class="tarjeta"><h4>Integridad</h4><p>Se intenta ingresar datos inválidos. Cada acción debe mostrar un error controlado:</p>
        <ul>
          <li>Un estudiante con un código que ya existe.</li>
          <li>Horas asignadas a una inscripción que no existe.</li>
          <li>Horas negativas o mayores al máximo diario.</li>
          <li>El mismo estudiante inscrito dos veces en un proyecto.</li>
        </ul></div>
      <div class="tarjeta"><h4>Funcionales</h4><p>Se cargan datos de ejemplo con cantidades conocidas y se comparan las consultas con cálculos hechos a mano:</p>
        <ul>
          <li>Total de horas acumuladas y pendientes por estudiante.</li>
          <li>Lista de quienes terminaron, solo con quienes cumplieron el mínimo.</li>
          <li>Reportes por sección, proyecto, institución y año lectivo.</li>
        </ul></div>
      <div class="tarjeta"><h4>Seguridad</h4><p>Se revisa que cada rol acceda solo a lo que le toca:</p>
        <ul>
          <li>El administrador puede registrar y cambiar información.</li>
          <li>Los docentes solo certifican las horas de sus estudiantes.</li>
          <li>Los estudiantes solo consultan su propio avance.</li>
        </ul></div>
      <div class="tarjeta"><h4>Usuario</h4><p>Un grupo pequeño de usuarios reales, como el encargado del servicio social, algunos docentes y algunos estudiantes, usa el sistema y opina sobre lo fácil que es, lo claro de los formularios y la rapidez de las consultas.</p></div>
      <div class="tarjeta"><h4>Rendimiento y respaldo</h4><p>Las consultas y reportes deben responder en pocos segundos, incluso con un volumen de datos similar al de varios años lectivos. Las copias de seguridad se generan de forma automática y la información puede restaurarse sin pérdidas.</p></div>
    </div>
    <div class="destacado claro">Se documentan los resultados de todas las pruebas, junto con los errores encontrados y las correcciones hechas. Así, queda registro de que el sistema fue revisado antes de ponerse en marcha.</div>
  </article>

  <!-- 9 -->
  <article class="capitulo" id="resultados">
    <header><span class="num" aria-hidden="true">9</span><h2>Resultados</h2></header>
    <h3>SIGES como referencia</h3>
    <p>Los resultados se presentan tomando como referencia el Sistema de Información para la Gestión Educativa Salvadoreña (SIGES), la plataforma del Ministerio de Educación, Ciencia y Tecnología (MINEDUCYT). SIGES reúne la información de la administración educativa en una sola base de datos, lo que permite hacer consultas, gestión y estudios estadísticos.</p>
    <div class="rejilla">
      <div class="tarjeta gris"><h4>SIGES</h4><p>Alcance nacional. Reúne la información de la administración educativa en una sola base de datos.</p></div>
      <div class="tarjeta gris"><h4>SOCIALTECH</h4><p>Alcance de un solo centro educativo. Comparte el mismo principio: sustituir registros dispersos por una base de datos centralizada, confiable y fácil de consultar.</p></div>
    </div>

    <h3>Menos tiempo en tareas administrativas</h3>
    <p>SIGES hace más fácil el trabajo de los docentes al registrar información y permite sacar constancias y cuadros de promoción con rapidez. Con la base de datos propuesta pasa algo similar. El sistema calcula de forma automática el total de horas acumuladas y pendientes de cada estudiante, y las constancias de cumplimiento se pueden preparar en segundos, sin revisar expedientes uno por uno. Los reportes por sección, proyecto, institución y año lectivo, que antes tomaban horas de trabajo manual, se obtienen de inmediato y con datos que se pueden comprobar.</p>

    <h3>Calidad y confiabilidad de los datos</h3>
    <p>Las restricciones de integridad no permiten horas negativas, registros sin inscripción válida o sin docente certificador, ni inscripciones repetidas. SIGES también revisa sus registros para tener información limpia. En las pruebas con datos de ejemplo, se espera que los cálculos de la base de datos sean iguales a los hechos a mano y que las acciones no permitidas generen errores controlados. Esto muestra que la información guardada es consistente y se puede usar con confianza para decidir si un estudiante cumplió o no con su servicio social.</p>

    <h3>Transparencia y toma de decisiones</h3>
    <p>SIGES tiene un portal de datos abiertos que permite descargar información del sistema para usarla como microdatos. De forma similar, aunque en menor medida, las autoridades del centro educativo pueden saber cuántos estudiantes han completado sus horas, qué proyectos tienen más participación y qué instituciones colaboran más seguido. Cada estudiante puede revisar su avance con seguridad.</p>
    <div class="destacado"><small>En conjunto</small>Estos resultados muestran que la base de datos cumple con el objetivo principal y que su funcionamiento es parecido, en lo básico, al de los sistemas de gestión educativa que ya existen en el país.</div>
  </article>

  <!-- 10 -->
  <article class="capitulo" id="conclusiones">
    <header><span class="num" aria-hidden="true">10</span><h2>Conclusiones</h2></header>
    <h3>El problema y la solución</h3>
    <p>El desarrollo de este proyecto mostró que registrar manualmente las horas sociales en cuadernos, hojas impresas y archivos de Excel dispersos no es un método confiable para un requisito tan importante como la graduación del estudiante. Los errores de transcripción, la duplicidad de datos, la pérdida de información y la dificultad para consultar el avance de cada alumno muestran claramente la necesidad de una base de datos que centralice y organice esta información.</p>
    <h3>Objetivos cumplidos</h3>
    <p>Se cumple el objetivo general, ya que el diseño propuesto permite registrar, organizar y controlar las horas sociales de los estudiantes de bachillerato. También agiliza la consulta de información, la emisión de reportes y la elaboración de constancias. Los objetivos específicos se logran: el análisis de requisitos identificó las necesidades de la institución, el modelo entidad-relación y el diseño lógico muestran de forma adecuada a estudiantes, docentes, proyectos, instituciones y horas cumplidas, y las restricciones de integridad protegen los datos de duplicados y de registros incorrectos.</p>
    <h3>Orden, seguridad y coherencia</h3>
    <p>Usar un sistema gestor de bases de datos, junto con un diseño normalizado, da orden, seguridad y coherencia a la información. Definir roles de acceso asegura que cada usuario solo consulte o cambie lo que le toca, y las copias de seguridad periódicas cuidan el historial de los estudiantes. Además, el ejemplo de SIGES muestra que los sistemas de información centralizados mejoran la gestión educativa. Por eso, una solución parecida, pero más pequeña, es posible y útil para un solo centro educativo.</p>
    <div class="destacado claro">La base de datos ayuda a que todo sea más claro y a que se tomen mejores decisiones. Estudiantes, docentes y autoridades pueden ver información comprobable sobre el cumplimiento del servicio social.</div>

    <h3>Recomendaciones</h3>
    <ul class="lista">
      <li>Usar el sistema poco a poco.</li>
      <li>Capacitar al personal encargado.</li>
      <li>Mantener los datos al día.</li>
      <li>Hacer copias de seguridad de la información de forma constante.</li>
    </ul>
    <h3>Trabajo a futuro</h3>
    <ul class="lista">
      <li>Desarrollar una página web para que los estudiantes consulten su avance desde cualquier dispositivo.</li>
      <li>Revisar si se puede conectar la base de datos con los sistemas oficiales del centro educativo.</li>
    </ul>
  </article>

  <!-- 11 -->
  <article class="capitulo" id="anexos">
    <header><span class="num" aria-hidden="true">11</span><h2>Documentación y anexos</h2></header>
    <h3>Documentación del proyecto</h3>
    <p>La documentación reúne todos los materiales que apoyan el diseño, el desarrollo y el uso de la base de datos. Así, cualquier persona de la institución puede entenderla, mantenerla y seguir trabajando con ella en el futuro.</p>
    <ul class="lista">
      <li>Este documento, que describe el problema, los objetivos, el análisis de requisitos, el diseño, la implementación, las pruebas y los resultados.</li>
      <li>Un diccionario de datos que detalla cada tabla y cada campo, con su tipo de dato, su longitud, si es obligatorio o no y las restricciones que se le aplican. Es muy útil cuando cambia el personal encargado, porque permite entender la estructura sin depender de quien la diseñó.</li>
    </ul>

    <h3>Anexos</h3>
    <div class="rejilla">
      <div class="tarjeta"><h4>Anexos técnicos</h4>
        <ul>
          <li>Diagrama entidad-relación, con las entidades del sistema y sus relaciones.</li>
          <li>Modelo lógico con las tablas, claves primarias y claves foráneas.</li>
          <li>Script SQL completo: tablas, restricciones de integridad, datos iniciales, consultas y reportes principales.</li>
        </ul>
        <p style="margin-top:.7rem">Con el script, la base de datos puede crearse de nuevo en otro equipo o recuperarse si ocurre una falla.</p></div>
      <div class="tarjeta"><h4>Anexos de uso</h4>
        <ul>
          <li>Manual breve para los usuarios: ingresar al sistema, registrar estudiantes, proyectos e instituciones, anotar y certificar horas, consultar el avance y generar constancias. Con indicaciones para el encargado del servicio social, los docentes asesores y los estudiantes.</li>
          <li>Manual de mantenimiento: cómo realizar y restaurar copias de seguridad, administrar usuarios y permisos, y qué hacer ante los errores más comunes.</li>
        </ul></div>
      <div class="tarjeta"><h4>Anexos de evidencia</h4>
        <ul>
          <li>Capturas de pantalla de las tablas, los formularios y los reportes.</li>
          <li>Formatos de ejemplo que la institución usaba para llevar el registro a mano.</li>
          <li>Registro de pruebas con los casos aplicados, los resultados obtenidos y las correcciones hechas.</li>
          <li>Opcional: modelo de constancia de cumplimiento del servicio social.</li>
        </ul></div>
    </div>
    <div class="destacado claro">Estos materiales permiten ver que se probó el sistema y que mejora el proceso anterior. También sirven como respaldo en caso de revisión por parte de docentes, autoridades o evaluadores del proyecto.</div>
  </article>

  <!-- Referencias -->
  <article class="capitulo" id="referencias">
    <header><span class="num" aria-hidden="true">R</span><h2>Referencias</h2></header>
    <ul class="refs">
      <li>Ministerio de Educación, Ciencia y Tecnología de El Salvador (MINEDUCYT). <em>Sistema de Información para la Gestión Educativa Salvadoreña (SIGES).</em> <a href="<?php echo esc_url( 'https://siges.sv/inicio' ); ?>" target="_blank" rel="noopener">https://siges.sv/inicio</a></li>
      <li>Sofis Solutions. (14 de abril de 2019). <em>The first stage of SIGES implementation concludes - El Salvador.</em> <a href="<?php echo esc_url( 'https://www.sofis.lat/en/news-detail/first-phase-of-siges-implementation-completed-in-el-salvador' ); ?>" target="_blank" rel="noopener">https://www.sofis.lat/en/news-detail/first-phase-of-siges-implementation-completed-in-el-salvador</a></li>
      <li>SIGES Open Data. <em>Portal de datos abiertos del Sistema de Información para la Gestión Educativa Salvadoreña.</em> <a href="<?php echo esc_url( 'https://ckan.siges.sv/' ); ?>" target="_blank" rel="noopener">https://ckan.siges.sv/</a></li>
    </ul>
  </article>

  <!-- Cuenta -->
  <?php
  $mensajes = array(
    'registrado'           => array( 'ok',    'Tu cuenta se creó y ya iniciaste sesión. ¡Bienvenido a SOCIALTECH!' ),
    'ya_sesion'            => array( 'ok',    'Ya tienes una sesión iniciada.' ),
    'login_error'          => array( 'error', 'Usuario o contraseña incorrectos. Inténtalo de nuevo.' ),
    'error_seguridad'      => array( 'error', 'No se pudo verificar el formulario. Recarga la página e inténtalo otra vez.' ),
    'error_cerrado'        => array( 'error', 'El registro de cuentas está desactivado en este sitio.' ),
    'error_campos'         => array( 'error', 'Completa todos los campos para crear tu cuenta.' ),
    'error_usuario'        => array( 'error', 'El nombre de usuario no es válido. Usa letras, números, puntos o guiones.' ),
    'error_correo'         => array( 'error', 'El correo electrónico no es válido.' ),
    'error_usuario_existe' => array( 'error', 'Ese nombre de usuario ya está en uso. Elige otro.' ),
    'error_correo_existe'  => array( 'error', 'Ya existe una cuenta con ese correo. Inicia sesión o usa otro correo.' ),
    'error_clave_corta'    => array( 'error', 'La contraseña debe tener al menos 8 caracteres.' ),
    'error_claves'         => array( 'error', 'Las contraseñas no coinciden.' ),
    'error_generico'       => array( 'error', 'No se pudo crear la cuenta. Inténtalo de nuevo más tarde.' ),
  );
  $codigo = isset( $_GET['cuenta'] ) ? sanitize_key( wp_unslash( $_GET['cuenta'] ) ) : '';
  $aviso  = isset( $mensajes[ $codigo ] ) ? $mensajes[ $codigo ] : null;
  $registro_abierto = (bool) get_option( 'users_can_register' );
  ?>
  <article class="capitulo cuenta" id="cuenta">
    <header><span class="num" aria-hidden="true">@</span><h2><?php echo is_user_logged_in() ? 'Mi cuenta' : 'Registrarse o iniciar sesión'; ?></h2></header>

    <?php if ( $aviso ) : ?>
      <div class="aviso aviso--<?php echo esc_attr( $aviso[0] ); ?>" role="<?php echo 'error' === $aviso[0] ? 'alert' : 'status'; ?>"><?php echo esc_html( $aviso[1] ); ?></div>
    <?php endif; ?>

    <?php if ( is_user_logged_in() ) : $u = wp_get_current_user(); ?>

      <div class="perfil">
        <div class="perfil__avatar" aria-hidden="true"><?php echo esc_html( mb_strtoupper( mb_substr( $u->display_name, 0, 1 ) ) ); ?></div>
        <div>
          <h3 style="margin:0 0 .3rem">Hola, <?php echo esc_html( $u->display_name ); ?></h3>
          <p><strong>Usuario:</strong> <?php echo esc_html( $u->user_login ); ?></p>
          <p><strong>Correo:</strong> <?php echo esc_html( $u->user_email ); ?></p>
          <p><strong>Miembro desde:</strong> <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $u->user_registered ) ) ); ?></p>
          <p class="perfil__acciones">
            <a class="boton" href="<?php echo esc_url( get_edit_profile_url() ); ?>">Editar mi perfil</a>
            <a class="boton boton--claro" href="<?php echo esc_url( wp_logout_url( home_url( '/#cuenta' ) ) ); ?>">Cerrar sesión</a>
          </p>
        </div>
      </div>

    <?php else : ?>

      <p>Crea tu cuenta personal para entrar a SOCIALTECH. Si ya tienes una, inicia sesión.</p>
      <div class="rejilla rejilla--cuenta">

        <section class="panel" aria-labelledby="t-login">
          <h3 id="t-login">Ya tengo cuenta</h3>
          <div class="form-login">
            <?php
            wp_login_form( array(
              'echo'           => true,
              'redirect'       => home_url( '/#cuenta' ),
              'form_id'        => 'socialtech-login',
              'label_username' => 'Usuario o correo',
              'label_password' => 'Contraseña',
              'label_remember' => 'Mantener mi sesión iniciada',
              'label_log_in'   => 'Iniciar sesión',
              'remember'       => true,
            ) );
            ?>
          </div>
          <p class="leyenda"><a href="<?php echo esc_url( wp_lostpassword_url( home_url( '/#cuenta' ) ) ); ?>">¿Olvidaste tu contraseña?</a></p>
        </section>

        <section class="panel" aria-labelledby="t-registro">
          <h3 id="t-registro">Crear una cuenta</h3>
          <?php if ( $registro_abierto ) : ?>
            <form class="form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
              <input type="hidden" name="action" value="socialtech_registro">
              <?php wp_nonce_field( 'socialtech_registro', 'socialtech_nonce' ); ?>
              <div class="trampa" aria-hidden="true"><label>No llenar este campo<input type="text" name="sitio_web" tabindex="-1" autocomplete="off"></label></div>

              <label for="reg-nombre">Nombre completo</label>
              <input id="reg-nombre" name="nombre" type="text" autocomplete="name" required>

              <label for="reg-usuario">Nombre de usuario</label>
              <input id="reg-usuario" name="usuario" type="text" autocomplete="username" required>

              <label for="reg-correo">Correo electrónico</label>
              <input id="reg-correo" name="correo" type="email" autocomplete="email" required>

              <label for="reg-clave">Contraseña <span class="ayuda">(mínimo 8 caracteres)</span></label>
              <input id="reg-clave" name="clave" type="password" minlength="8" autocomplete="new-password" required>

              <label for="reg-clave2">Repite la contraseña</label>
              <input id="reg-clave2" name="clave2" type="password" minlength="8" autocomplete="new-password" required>

              <button class="boton" type="submit">Crear mi cuenta</button>
            </form>
          <?php else : ?>
            <div class="aviso aviso--error" role="status">
              El registro de cuentas está desactivado.
              <?php if ( current_user_can( 'manage_options' ) ) : ?>
                Para activarlo, ve a Ajustes → Generales y marca «Cualquiera puede registrarse».
              <?php endif; ?>
            </div>
          <?php endif; ?>
        </section>

      </div>

    <?php endif; ?>
  </article>

  </main>
</div>

<?php get_footer(); ?>
